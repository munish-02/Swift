import Cocoa
var varA:String?
varA="munish"
if let string1 = varA
{
    print("\(string1)")
}
else
{
    print("String does not have any value")
}
print("Value of \(varA) is more than millions")
print((1..<5))

